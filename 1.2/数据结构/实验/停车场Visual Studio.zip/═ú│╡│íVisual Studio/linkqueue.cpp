#include "datastructure.h"
#include "linkqueue.h"
void InitQueue(LinkQueue &Q)
{
	Q.front=Q.rear=(QueuePtr)malloc(sizeof(QNode));
	if(!Q.front) exit (OVERFLOW);
	Q.front->next=NULL;
}
void EnQueue(LinkQueue &Q,QElemType e)
{
	QueuePtr p;
	p=(QueuePtr)malloc(sizeof(QNode));
	if(!p) exit(OVERFLOW);
	p->data=e;
	p->next=NULL;
	Q.rear->next=p;
	Q.rear=p;
}
void DeQueue(LinkQueue &Q,QElemType &e)
{
	QueuePtr p;
	if (Q.front==Q.rear) return;
	p=Q.front->next;
	e=p->data;
	Q.front->next=p->next;
	if(Q.rear==p) Q.rear=Q.front;
	free(p);
}
bool QueueEmpty(LinkQueue Q)
{
	if(Q.front==Q.rear) 
		return true;
	else
		return false;	
}
int LocateQe(LinkQueue Q,QElemType e)//����e�ڶ���Q�е�λ��,û�ҵ�������0
{	int n=0;
	QueuePtr p=Q.front;
	while(p!=Q.rear)
	{	n++;
		p=p->next;
	}
	return n;
}
void GetFront(LinkQueue Q,QElemType &e)
{
	if (Q.front==Q.rear) return;
	e=Q.front->next->data;
}

