package week13;

import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
//all the files have been already created before used,so I don't check whether it exists
public class MAIN {
	public static void key_init(String key_path) {
//		it is not suitable to make max very big, otherwise the secret txt will be very ugly
		int key[] = new int[128], min = 0, max = 10;
		Random rand = new Random();
		for(int i = 0; i < 128; i++) 
			key[i] = rand.nextInt(max - min + 1) + min;
		File file_key = new File(key_path);
		try{
			FileWriter wr = new FileWriter(file_key);
			for(int i = 0; i < 128; i++) {
				wr.write(String.valueOf(key[i]));
				if((i + 1) % 20 == 0)
					//add a line separator
					wr.write(System.lineSeparator()); 
				else
					//add a space
					wr.write(" "); 
			}
			System.out.println("successfully write into key file" + "\n");
			//check the content of the array 'key'
			System.out.println("the key is as below:");
			for(int i = 0; i < 128; i++) {
				System.out.print(key[i]);
				if((i + 1) % 20 == 0)
					System.out.println();
				else 
					System.out.print(" ");
			}	
			System.out.println("\n");
			wr.close();
		}catch(IOException e) {
			System.out.println("something wrong happened when writing to key txt" +	"\n" + e.getMessage() + "\n");
		}
	}
	public static void key_get(int key[],String key_path) {
		 List<Integer> integers = new ArrayList<>();  
	        try (BufferedReader reader = new BufferedReader(new FileReader(key_path))) {  
	            String line;  
	            while ((line = reader.readLine()) != null) {  
	                String[] values = line.trim().split("\\s+");  
	                for (String value : values) 
	                    integers.add(Integer.parseInt(value));  
	            }  
	        } catch (IOException | NumberFormatException e) {  
	            e.printStackTrace();  
	        }  
	  
	       int i;
	        for (i = 0; i < integers.size(); i++)  
	            key[i] = integers.get(i);
	    }  
	
	public static String test(String test_path) {
	    String s = ""; // 或者根据需求初始化一个字符串
	    FileInputStream fin = null;
	    try {
	        fin = new FileInputStream(test_path);
	        byte[] buffer = new byte[1024];
	        int num = fin.read(buffer, 0, 1024);
//	        System.out.println(num);
	        s = new String(buffer).trim();
//	        System.out.println(s);
	    } catch (Exception e) {
	        System.out.println(e.toString());
	    }
	    System.out.println("the original string is: ");
	    System.out.println(s + "\n");
	    return s;
	}
	
	public static void secret(int key[],String s,String secret_path) {
		char []ch = new char[s.length()];String s1 = "";
		for(int i = 0; i < s.length(); i++) { 
			ch[i] = s.charAt(i);
			if(ch[i] >= '0' && ch[i] <= '9') 
				ch[i] = (char)((int)ch[i] + 1 + key[i%128]);
			else if(ch[i] >= 'a' && ch[i] <= 'z')
				ch[i] = (char)((int)ch[i] + 2 + key[i%128]);
			else if(ch[i] >= 'A' && ch[i] <= 'Z')
				ch[i] = (char)((int)ch[i] + 3 + key[i%128]);
			else 
				ch[i] = (char)((int)ch[i] + 4 + key[i%128]);
		}
		s1 = new String(ch);
	    System.out.println("the secret string is: ");
		System.out.println(s1 + "\n");
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(secret_path))) {  
            writer.write(s1);  
            System.out.println("successfully write into secret file" + "\n");  
        } catch (IOException e) {  
            e.printStackTrace();  
            System.out.println("something wrong happened when writing to secret txt" +	"\n" + e.getMessage() + "\n");  
        }  
	}
	public static void decrypt(int key[],String secret_path,String decrypt_path) {
		String s = test(secret_path);
	    System.out.println("the secret string should be: ");
		System.out.println(s + "\n");
		char []ch = new char[s.length()];String s1 = "";
		for(int i = 0; i < s.length(); i++) {
			ch[i] = s.charAt(i);
			ch[i] = (char)(ch[i] - key[i%128]);
			if(ch[i] - 1 >= '0' && ch[i] - 1 <= '9')
				ch[i] = (char)((int)ch[i] - 1);
			else if(ch[i] - 2 >= 'a' && ch[i] - 2 <= 'z')
				ch[i] = (char)((int)ch[i] - 2);
			else if(ch[i] - 3 >= 'A' && ch[i] - 3 <= 'Z')
				ch[i] = (char)((int)ch[i] - 3);
			else
				ch[i] = (char)((int)ch[i] - 4);
		}
		s1 = new String(ch);
	    System.out.println("the original string should be: ");
		System.out.println(s1 + "\n");
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(decrypt_path))) {  
            writer.write(s1);  
            System.out.println("successfully write into decrypt file" + "\n");  
        } catch (IOException e) {  
            e.printStackTrace();  
            System.out.println("something wrong happened when writing to decrypt txt" +	"\n" + e.getMessage() + "\n");  
        }  
	}
	public static void main(String []args) {
		int key[] = new int[128];String s = "";
		String key_path = "D:\\eclipse\\week13\\key.txt";
		String test_path = "D:\\eclipse\\week13\\test.txt";
		String secret_path = "D:\\eclipse\\week13\\secret.txt";
		String decrypt_path = "D:\\eclipse\\week13\\decrypt.txt";
		key_init(key_path);key_get(key,key_path);
		s = test(test_path); secret(key,s,secret_path);
		decrypt(key,secret_path,decrypt_path);
	
	}
}
