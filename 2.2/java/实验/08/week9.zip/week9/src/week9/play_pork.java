package week9;

import java.util.Random;

public class play_pork {
	int t = 4;//人数
	int a[] = new int[52];//发牌顺序
	card c[] = new card[52];//存放牌
	player p[] = new player[t];
	play_pork() {
		int m = 0;
		for(int i=0;i<52;i++)a[i]=0;
		for(int i = 0;i < 13;i++) {
			for(int j = 0;j < 4;j++) {
				c[m] = new card(); 
				c[m++].set(j, i + 1); 
			}
		}
		shuffle();
	}
	play_pork(int tt){
		t = tt;		int m = 0;
		for(int i=0;i<52;i++)a[i]=0;
		for(int i = 0;i < 13;i++) {
			for(int j = 0;j < 4;j++) {
				c[m] = new card(); 
				c[m++].set(j, i + 1); //按花色顺序放牌
			}
		}
		for(int i = 0;i < 4;i++) {
			p[i] = new player();
			p[i].set_num(i);
		}
		shuffle();
	}
	public void shuffle() {//洗牌
		Random r = new Random();int m;
		for(int i=0;i<52;i++) {
			m = r.nextInt(52);//顺序在a[]中
			for(int j = 0;j<52;j++) {
				if(a[j] == m) {		//检查重复
					m = r.nextInt(52); //重新生成
					j--;
				}
			}
			a[i] = m;
//			System.out.println(a[i]);
		}
	}
	public int judge_huihe(int m) {//回合结束
		if(m == t-1)
			return 1;
		else 
			return 0;
	}
	public int judge_game(int i) {//游戏结束
		if(p[i].judge(i) == 2) {
			System.out.println("游戏结束");
			return 1;
		}
		else 
			return 0;
	}
	public void fa_pai(player p[]) {//发牌并整理
		int k,l;
		for(int j = 0,m = 0;j < 4 && m<52;j++,m++) {
			k=c[a[m]].get_type();l=c[a[m]].get_num();
			p[j].set(k,l);
			if(j == 3) j = -1;
		}

		for(int i = 0;i < 4;i++) {
			p[i].put_away();
//			p[i].show_all_card();
		}
		
	}
	public void get_score(int x[],player p[]) {//得分
		int a[] = new int [4];
		for(int i = 0;i < 4;i++) 
			a[i] = x[i];
		for(int i = 0;i < 3;i++) {
			for(int j = 0;j < 3 - i;j++) {
				if (a[j] > a[j + 1]) {
					a[j] = a[j + 1] + a[j];	a[j + 1] = a[j] - a[j + 1];a[j] = a[j] - a[j + 1];
				}
			}
		}
		for(int i=0;i<4;i++) 
			for(int j=0;j<4;j++) 
				if(x[j]==a[i]) 
					p[j].score += 4-i;	
	}
	public void play(player p[]) {//进行游戏
		int x[] = new int[4];
		for(int i = 0;i < 4;i++) {
			if(p[i].judge(i) == 1) {
				x[i] = p[i].discard().get_num();
			}
			if(judge_huihe(i) == 1) {
				get_score(x,p);
				i=0;
			}
			if(judge_game(i) == 1) 
				break;
		}
		
	}
	public void begin_game() {
		fa_pai(p);	play(p);
		int a[] = new int [4];
		for(int i = 0;i < 4;i++) 
			a[i] = p[i].score;
		for(int i = 0;i < 3;i++) {
			for(int j = 0;j < 3 - i;j++) {
				if (a[j] < a[j + 1]) {
					a[j] = a[j + 1] + a[j];	a[j + 1] = a[j] - a[j + 1];a[j] = a[j] - a[j + 1];
				}
			}
		}
		for(int i = 0;i < 4;i++) 
			for(int j = 0;j < 4;j++) 
				if(p[j].score == a[i]) 
					System.out.println("第"+i+"名是"+j+"号玩家，得分"+p[j].score);
					
				
	}
	
}
