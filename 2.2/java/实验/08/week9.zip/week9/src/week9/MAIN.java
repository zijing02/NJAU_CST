package week9;

//char a[]= {'A','2','3','4','5','6','7','8','9','X','J','Q','k'};
//int b[]= {1,2,3,4};

public class MAIN {
	public static void main(String args[]) {
	play_pork g = new play_pork(4);
	g.begin_game();
	
	}
}
