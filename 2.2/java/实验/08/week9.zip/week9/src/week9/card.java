package week9;
public class card {
	int a;int b;
	card(){}
	card(int i,int j){b = i;a = j;}
	public void set(int i,int j){b = i;a = j;}
	public int get_type() {return b;}
	public int get_num() {return a;}
	public void show_type() {System.out.print(b);}
	public void show_num() {System.out.print(a);}
	public void show_all() {System.out.print("花色："+b+"大小："+a+'\n');}	
}
