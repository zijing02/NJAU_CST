package week9;

public class player {
	int number;//编号
	String name;//姓名
	int max = 13;//最大牌数
	int	num[][] = new int[4][];//4种花色牌,每一维一种花色，第一个是总数，后面是不同的牌,分配十三个位置，有牌置一，浪费空间换取时间
	int hold_num = 0,score = 0;//总分
	player(){
		for(int i = 0;i < 13;i++) {
			hold_card[i] = new card();
			hold_card[i].set(5, 14);
		}
		for(int i=0;i<4;i++) 
			num[i] = new int[14];	
	}
	player(String tname,int tmax,int m){
		name = tname;max = tmax;hold_num = max;
		for(int i = 0;i < 13;i++) {
			hold_card[i] = new card();
			hold_card[i].set(5,14);
		}
		for(int i=0;i<4;i++) 
			num[i] = new int[14];	
		number = m;
	}
	card hold_card[]=new card[max]; 
	public void set_num(int i) {number = i;}
	public void set(int m,int n) {
//		System.out.print(hold_num);
		hold_card[hold_num].a = n;	
		hold_card[hold_num++].b = m;
	}
	public void put_away() {//理牌
		for(int i = 0;i < max;i++) {
			num[hold_card[i].get_type()][0]++;
			num[hold_card[i].get_type()][hold_card[i].get_num()]++;
		}
	}
	public int judge(int index) {
		if(hold_num == 0) 
//			System.out.print("编号为"+number+"的玩家胜出");
			return 2;
		
		else {
			if(number != index) 
				return 0;
			hold_num--;
			return 1;
		}
	}
	public card discard() {
		card result = new card();
		for(int i = 0;i < 4;i++) {
			if(num[i][0]!=0) {
				num[i][0]--;
				for(int j = 1;j < 14;j++) {
					if(num[i][j]!=0) {
						result.set(i, j);
						num[i][j]=0;
						return result;
					}
				}
			}	
		}
		result.set(5,0);
		return result;
	}
	public card discard(card t) {
		int m = t.get_type();card result = new card();
		if(num[m][0] == 0) {
			for(int i = 0;i < 4&&i!=m;i++) {
				for(int j = 1;j < 14;j++) {
					if(num[i][j]!=0) {
						result.set(i, j);
						num[i][j]=0;
						return result;
					}
				}
			}
		}
		else {
			for(int i = 1;i < 14;i++) {
				if(num[m][i]!=0) {
					result.set(m, i);
					num[m][i]=0;
					return result;
				}
			}
		}
		result.set(5,0);
		return result;	
				
	}
	public void show_all_card() {
		for(int i = 0;i < max;i++) {
			hold_card[i].show_all();}
		System.out.print('\n');
	}
}
