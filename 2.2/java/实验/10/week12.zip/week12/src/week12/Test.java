package week12;

public class Test {
	public static void main(String args[]){
		Park p = new Park();
		
		MyJFrame fr = new MyJFrame(p);
	
	}
}
