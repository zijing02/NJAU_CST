package week7;


public class MAIN {
	public static void main(String []args) {
		SheepArray s = new SheepArray(3,"jack",0);
//		System.out.print(s.total_num);
		sheep s1 = new sheep("肉羊","白色",5,100,3);
		s.set();
		s.show_all();
		s.get_fattest();
		s.sort();
		s.insert(s1);
		s.find(2);
		s.show_all();
	}
}
//肉羊
//黑色
//1 113 2

//宠物羊
//白色
//2 78 1

//肉羊
//黄色
//3 108 2
