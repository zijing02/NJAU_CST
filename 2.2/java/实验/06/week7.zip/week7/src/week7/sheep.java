package week7;
import java.util.Scanner;
//int i=sc.nextInt()
public class sheep {
	String type,colour;int num,weight,inject_num;
	Scanner sc=new Scanner(System.in);
	sheep(){}
	sheep(String ttype,String tcolour,int tnum,int tweight,int tinject_num){
		type=ttype;colour=tcolour;num=tnum;weight=tweight;inject_num=tinject_num;
	}
	public void set() {
		type=sc.nextLine();
		colour=sc.nextLine();
		num=sc.nextInt();
		weight=sc.nextInt();
		inject_num=sc.nextInt();
	}
	public String get_type() {return type;}
	public String get_colour() {return colour;}
	public int get_num() {return num;}	
	public int get_weight() {return weight;}
	public int get_inject_num() {return inject_num;}
	public void show() {System.out.println("编号："+num+" 类型："+type+" 重量："+weight+" 颜色："+colour+" 注射次数："+inject_num+"\n");}

}
