package week7;

public class SheepArray {
	String owner;int array_num,total_num;sheep []s=new sheep[100];
	SheepArray(int ttotal_num,String towner,int tarray_num){
		owner=towner;total_num=ttotal_num;array_num=tarray_num;
		s=new sheep[100];
	}
	public void set() {
		for(int i=0;i<total_num;i++) {
			System.out.println("请输入第"+(i+1)+"只羊的信息(共"+total_num+"只羊)，依次为类型，颜色，编号，重量，注射次数:");
			s[i]=new sheep();
			s[i].set();
			s[i].show();
		}
		System.out.println("输入完成\n");
	}
	public void get_fattest() {
		int weight=0;int k=0,i=0,j=0;
		for(i=0;i<total_num;i++) {
			if(s[i].weight>weight) {
				weight=s[i].weight;
				k=s[i].num;
				j=i;
			}
		}
		System.out.println("最肥的羊是"+k+"号\n");
		s[j].show();
	}
	public void sort() {
		sheep t;
		for(int i=0;i<total_num-1;i++) {
			for(int j=0;j<total_num-1-i;j++) {
				if(s[j].weight>s[j+1].weight) {
					t=s[j];s[j]=s[j+1];s[j+1]=t;					
				}				
			}
		}
		for(int i=0;i<total_num;i++)
			System.out.print(s[i].weight+" ");
		System.out.println("\n排序完成\n");

	}
	public void insert(sheep t) {
		int i=0,j;
		while(s[i++].weight<t.weight);
		i--;
		for(j=total_num+1;j>i;j--) 
			s[j]=s[j-1];
		s[j]=t;	total_num++;
		System.out.println("插入成功\n");
	}
	public void find(int n) {
		System.out.print("注射次数为"+n+"的羊有：\n");
		for(int i=0;i<total_num;i++) {
			if(s[i].inject_num==n)
				s[i].show();
		}
	}
	public void show_all() {
		System.out.println("所有羊的信息如下：\n");
		for(int i=0;i<total_num;i++)
			s[i].show();	
	}
}
