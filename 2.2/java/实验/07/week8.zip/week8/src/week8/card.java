package week8;
import java.util.Scanner;

public class card extends account{
	public int states;String type;double balance;
	Scanner sc=new Scanner(System.in);
	card(){}
	card(int ta,int ts,String tt,double tb){balance = tb; type = tt; super.acc_num = ta; states = ts; }
	public void chong_zhi() {System.out.println("请输入充值金额:");int t =sc.nextInt();balance += t;}
}
