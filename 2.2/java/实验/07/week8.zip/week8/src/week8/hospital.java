package week8;

public interface hospital {
	public void see_doctor();
}
