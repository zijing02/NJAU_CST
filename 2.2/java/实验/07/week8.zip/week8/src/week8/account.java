package week8;

public class account {
	int acc_num;String name,password;	//名字，密码在测试时均不使用
	account(){}
	account(int ta ,String tname,String tpassword){acc_num=ta;name = tname;password = tpassword;}
}
