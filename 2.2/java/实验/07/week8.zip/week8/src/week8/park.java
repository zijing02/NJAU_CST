package week8;

public interface park {
	public void go_to_park();

}
