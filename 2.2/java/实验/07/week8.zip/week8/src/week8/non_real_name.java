package week8;

public class non_real_name extends bus_card{
	non_real_name(){super.states = 0; }
	non_real_name(double ta,int tb){super.balance = ta; super.acc_num = tb; super.states = 0;}
	public void show() {
		System.out.println("账户信息：非实名卡 账户：" + super.acc_num +" 账户余额：" + super.balance);
	}
}
