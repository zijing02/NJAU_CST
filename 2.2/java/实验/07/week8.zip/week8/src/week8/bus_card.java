package week8;

public class bus_card extends card{
	String sb_type = "bus";
	bus_card(){	super.type = sb_type;}
	public void take_bus(int total_distance) {
		if(super.states == 0) {
			if(super.balance<total_distance/10) {
				System.out.println("余额不足，请充值");
				super.chong_zhi();
			}
			else
				super.balance -= total_distance/10;		
		}
		else {
			if(super.balance<total_distance/11) {
				System.out.println("余额不足，请充值");
				super.chong_zhi();
			}
			else
				super.balance -= total_distance/10;
		}
	}
}
