package week8;

public class real_name extends bus_card implements hospital,park{
	real_name(){}
	real_name(double tb,int ta){super.acc_num = ta; super.balance = tb;super.states = 1;}
	public void see_doctor() {
		if(super.balance >= 10)
			super.balance -= 10;
		else {
			System.out.println("余额不足，请充值");
			super.chong_zhi();
		}
	}
	public void go_to_park() {
		if(super.balance >= 2)
			super.balance -= 2;
		else {
			System.out.println("余额不足，请充值");
			super.chong_zhi();
		}
	}
	public void show() {
		System.out.println("账户信息：实名卡 账户：" + super.acc_num +" 账户余额：" + super.balance);
	}
}
