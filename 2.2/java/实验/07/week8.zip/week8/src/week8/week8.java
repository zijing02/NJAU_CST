package week8;
import java.util.Scanner;

public class week8 {
	public static void main(String []args) {
		Scanner sc=new Scanner(System.in);
		double ba;int acc, state = 0, num;char c;
		non_real_name card1 = new non_real_name();
		real_name card2 = new real_name();
		System.out.println("是否实名？（y/n）");					//可以使用while循环注册多张卡
		c = sc.next().charAt(0);
		System.out.println("请输入充值金额、想要注册的账户：");
		if(c == 'n' || c == 'N') {
			state = 0;
			ba = sc.nextDouble();acc = sc.nextInt();	
			card1 = new non_real_name(ba,acc);
			card1.show();
		}
		if(c == 'y' || c == 'Y') {
			state = 1;
			ba = sc.nextDouble();acc = sc.nextInt();	
			card2 = new real_name(ba,acc);
			card2.show();
		}
		System.out.println("选择需要的服务：a.乘车  b.看病  c.去公园");	//可以使用while循环一直操作
		c = sc.next().charAt(0);
		System.out.println("选择卡的类型：1.实名  2.未实名");		//此处卡多后应该用遍历卡组选取卡号
		state = sc.nextInt();
		if(c == 'a' || c == 'A') {
			System.out.println("请输入乘坐里程（公里）");
			num = sc.nextInt();
			if(state == 1) {
				card2.take_bus(num);			
				card2.show();
			}
			else {
				card1.take_bus(num);
				card1.show();
			}
		}
		if(c == 'b' || c == 'B') {
			if(state == 1) {
				card2.see_doctor();
				card2.show();
			}
			else
				System.out.println("卡类型错误，无法使用");
		}
		if(c == 'c' || c == 'C') {
			if(state == 1) {
				card2.go_to_park();
				card2.show();
			}
			else
				System.out.println("卡类型错误，无法使用");
		}
	}
	
}
