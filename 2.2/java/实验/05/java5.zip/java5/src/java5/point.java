package java5;

public class point {
	public int x,y;
	point(){x=y=0;}
	point(int tx,int ty){x=tx;y=ty;}
	public int getx() {return x;}
	public int gety() {return y;}
}
