package java5;

import java.awt.Graphics;

public class house {
	public point a1,a2,a3;
	public door[]doors=new door[2];
	public windows []windows=new windows[4];
	public int h;
	public circle c;
	house(int tx1,int ty1,int tx2,int ty2,int tx3,int ty3,int th) {
		a1=new point(tx1,ty1);a2=new point(tx2,ty2);a3=new point(tx3,ty3);
		h=th;doors[0]=new door(40,70,20,30);doors[1]=new door(130,70,20,30);
		windows[0]=new windows(10,70,20,20,2,2);windows[2]=new windows(100,70,20,20,2,2);
		windows[1]=new windows(70,70,20,20,2,2);windows[3]=new windows(160,70,20,20,2,2);
		c=new circle(0,50,12);
	}
	public void sethouse(int tx1,int ty1,int tx2,int ty2,int tx3,int ty3,int th) {
		a1=new point(tx1,ty1);a2=new point(tx2,ty2);a3=new point(tx3,ty3);
		h=th;doors[0]=new door(40,70,20,30);doors[1]=new door(130,70,20,30);
		windows[0]=new windows(10,70,20,20,2,2);windows[2]=new windows(100,70,20,20,2,2);
		windows[1]=new windows(70,70,20,20,2,2);windows[3]=new windows(160,70,20,20,2,2);
		c=new circle(0,50,12);
	}
	public void drawhouse(Graphics g) {
		int	[]xpoints=new int[3];int ypoints[]=new int[3];
		xpoints[0]=a1.getx();	xpoints[1]=a2.getx();	xpoints[2]=a3.getx();
		ypoints[0]=a1.gety();	ypoints[1]=a2.gety();	ypoints[2]=a3.gety();
		g.drawRect(a2.getx(),a2.gety(),a3.getx()-a2.getx(),h);
		g.drawPolygon(xpoints,ypoints,3);
		doors[0].drawdoor(g);	doors[1].drawdoor(g);
		windows[0].drawwin(g);	windows[1].drawwin(g);	
		windows[2].drawwin(g);	windows[3].drawwin(g);
		g.drawOval(c.getx()-6,c.gety()-6,(int)c.getr(),(int)c.getr());
	}
}
