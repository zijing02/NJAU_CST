package java5;

public class circle {
	public int x,y,r;
	public circle(){}
	public circle(int tx,int ty,int tr){x=tx;y=ty;r=tr;}
	public int getx() {return x;}
	public int gety() {return y;}
	public int getr() {return r;}
}
