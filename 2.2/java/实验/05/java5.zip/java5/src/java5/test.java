package java5;

import java.awt.*;
public class test extends Panel {
	public void paint(Graphics g) {
		house house = new house(95,0,0,50,190,50,50);
		house.drawhouse(g);
	}
	public static void main(String args[]) {
		Frame f=new Frame("asd");
		test m=new test();
		f.add(m,"Center");
		f.setSize(200,200);
		f.setVisible(true);
	} 
	
}
