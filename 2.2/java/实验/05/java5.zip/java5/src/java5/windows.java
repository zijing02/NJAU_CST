package java5;

import java.awt.Graphics;

public class windows {
	public int x,y,w,h,m1,m2,m3,m4;
	public windows(){}
	public windows(int tx,int ty,int tw,int th,int tm1,int tm2){
		x=tx;y=ty;w=tw;h=th;m1=x+w/2;m2=y+h/2;m3=x+w;m4=y+h;}
	public void setwin(int tx,int ty,int tw,int th,int tm1,int tm2){
		x=tx;y=ty;w=tw;h=th;m1=x+w/2;m2=y+h/2;m3=x+w;m4=y+h;}
	public int getx() {return x;}
	public int gety() {return y;}
	public int getw() {return w;}
	public int geth() {return h;}
	public int getm1() {return m1;}
	public int getm2() {return m2;}
	public void drawwin(Graphics g) {
		g.drawRect(x, y, w, h);
		g.drawLine(m1, y, m1, m4);
		g.drawLine(x, m2, m3, m2);
		
	}
}
