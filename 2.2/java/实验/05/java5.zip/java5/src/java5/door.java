package java5;

import java.awt.Graphics;

public class door {
	public int x,y,w,h;
	public door(){x=y=w=h=0;}
	public door(int tx,int ty,int tw,int th){x=tx;y=ty;w=tw;h=th;}
	public void setdoorint(int tx,int ty,int tw,int th){x=tx;y=ty;w=tw;h=th;}
	public int getx() {return x;}
	public int gety() {return y;}
	public int getw() {return w;}
	public int geth() {return h;}
	public void drawdoor(Graphics g) {
		g.drawRect(x, y, w, h);
		g.drawOval(x+w-5, y+h*2/3-5, 5, 5);}
}

