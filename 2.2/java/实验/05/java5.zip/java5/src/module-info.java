/**
 * 
 */
/**
 * 
 */
module java5 {
	requires java.desktop;
}