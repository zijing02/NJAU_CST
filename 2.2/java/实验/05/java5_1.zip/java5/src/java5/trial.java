package java5;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
public class trial extends shape{
	public int a[]=new int[3],b[]=new int[3];
	public trial() {}
	public  trial(int ta[],int tb[]) {
		for(int i=0;i<3;i++) {
			a[i]=ta[i];
			b[i]=tb[i];
		}
	}
	public void getdata(int ta[],int tb[]) {
		for(int i=0;i<3;i++) {
			ta[i]=a[i];
			tb[i]=b[i];
		}
	}
	public void draw(Graphics g) {g.drawPolygon(a, b, 3);	}

}
