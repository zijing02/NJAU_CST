package java5;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
public class location {
	public int x,y;
	public location(){}
	public location(int tx,int ty) {x=tx;y=ty;}
	public int getx() {return x;}
	public int gety() {return y;}
	public void set(int tx,int ty) {x=tx;y=ty;}

}
