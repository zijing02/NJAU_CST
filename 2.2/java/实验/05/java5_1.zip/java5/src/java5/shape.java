package java5;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
public class shape extends location{
	public void setlocation(int tx,int ty) {x=tx;y=ty;}
	
	
}
