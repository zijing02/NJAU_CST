package java5;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;

public class rect extends shape{
	public int width,height;
	rect(){}
	rect(int tx,int ty,int tw,int th){
		x=tx;y=ty;width=tw;height=th;
	}
	public void getdata(int a[]) {a[0]=x;a[1]=y;a[2]=width;a[3]=height;}
	public void dawrect(Graphics g) {g.drawRect(x, y, width, height);}
}
