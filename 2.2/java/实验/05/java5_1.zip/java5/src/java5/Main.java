package java5;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
public class Main extends JFrame{
//
	public Main()
	{
		setSize(5000,3000);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}
//	public void paint(Graphics g)
//	{
//		g.setColor(Color.blue);
//		g.drawLine(50,30,450,260);//线段
//		g.drawRect(100,100,300,100);//直角矩形
//		g.drawRoundRect(500, 300, 400, 100, 40,40);//圆角矩形
//		int xp[]= {100,200,300};int yp[]= {150,300,180};
//		g.drawPolygon(xp,yp, 3);//三角形，使用多边形实现
//	}
//	public static void main(String[] args)
//	{
//		new Main().setVisible(true);
//	}
	public void paint(Graphics g)
	{
		g.setColor(Color.blue);
		g.drawRect(100,100,300,100);//直角矩形
		door c=new door(1,2,3,4);
		c.dawdoor(g);
		
	}
	public static void main(String[] args)
	{
		new Main().setVisible(true);
		
	}
}


