package java5;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
public class roof extends trial{
	roof(){}
}
