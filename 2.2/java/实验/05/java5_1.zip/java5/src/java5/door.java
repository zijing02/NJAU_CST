package java5;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
public class door extends rect{
	door(){}
	door(int tx,int ty,int tw,int th){
		x=tx;y=ty;width=tw;height=th;
	}
	public void getdoor(int a[]) {
		a[0]=x;a[1]=y;a[2]=width;a[3]=height;
	}
	public void dawdoor(Graphics g) {
		g.drawRect(x, y, width, height);	
	}
	
}
