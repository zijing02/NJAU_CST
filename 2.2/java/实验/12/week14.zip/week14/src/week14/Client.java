package week14;

import java.net.*;
import java.io.*;

public class Client {
    Socket s; 
    public Client() {
        try {
            s = new Socket("localhost", 5432); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void SendMessageToServer(String info) {  
        try {
            PrintStream out = new PrintStream(s.getOutputStream());
            out.print(info+"\r\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String GetMessageFromServer() {  
        String str = new String("");
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            str = br.readLine();
            return str;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public void CloseSocket() {
        try {
            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Client client = new Client();
        client.SendMessageToServer("Hello from client!");
        System.out.println("Message from server: " + client.GetMessageFromServer());
        client.CloseSocket();
    }
}