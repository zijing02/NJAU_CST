/**
 * 
 */
/**
 * 
 */
module week11 {
	requires java.desktop;
}