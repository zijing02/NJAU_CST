package week11;

import java.util.Arrays;
import java.util.Objects;
import java.util.Stack;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class calculator extends JFrame implements ActionListener{
	public double x = 0;
	public String[] key = {"MC","MR","MS","(",")","x^2","sqr","abs","CE","C","7","8","9","/","%","4","5","6","*","1/x","1","2","3","-","e","pi","0",".","+","="};
	public JButton[] keys = new JButton[key.length];
	public JTextArea result_text = new JTextArea();
	public JTextArea history = new JTextArea();
	public JPanel jp1 = new JPanel();
	public JPanel jp2 = new JPanel();
	public JScrollPane gdt1 = new JScrollPane();
	public JScrollPane gdt2 = new JScrollPane();
	public JLabel label = new JLabel("History");
	public String input = "";
	public calculator() {
		super("calculator");
		result_text.setBounds(20,18,255,115);
		result_text.setAlignmentX(RIGHT_ALIGNMENT);
		result_text.setEditable(false);
		result_text.setFont(new Font("momospaced",Font.PLAIN,10));
		result_text.setLineWrap(true);
		result_text.setWrapStyleWord(true);
		result_text.setSelectedTextColor(Color.blue);
		
		history.setBounds(290,40,250,370);
		history.setAlignmentX(RIGHT_ALIGNMENT);
		history.setEditable(false);
		history.setFont(new Font("momospaced",Font.PLAIN,10));
		history.setLineWrap(true);
		history.setWrapStyleWord(true);
		history.setSelectedTextColor(Color.blue);
		
		label.setBounds(300,15,100,20);
		jp1.setBounds(20, 18, 250, 115);
		jp1.setLayout(new GridLayout());
		jp2.setBounds(290, 40, 250, 370);
		jp2.setLayout(new GridLayout());
		
		gdt1.setViewportView(result_text);
		gdt2.setViewportView(history);
		jp1.add(gdt1);
		jp2.add(gdt2);
		this.add(jp1);
		this.add(jp2);
		this.setLayout(null);
		this.add(label);
		
		int x = 20, y = 150;
		for(int i = 0; i < key.length; i++) {
			keys[i] = new JButton();
			keys[i].setFont(new Font("momospaced",Font.PLAIN,10));
			keys[i].setText(key[i]);
			keys[i].setBounds(x, y, 50, 40);
			if(x < 215) x += 51;
			else {x = 20; y += 45;}
			this.add(keys[i]);
			keys[i].addActionListener(this);
		}
		this.setResizable(false);
		this.setBounds(500, 200, 580, 480);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		String label = e.getActionCommand();
		if(Objects.equals(label,"CE") || Objects.equals(label, "C")) {
			input = "";
			result_text.setText("0");
		}
		else if(Objects.equals(label,"x^2")) {
			String m;
			if(input.isEmpty()) m = "error";
			else m = String.valueOf(square(input));
			result_text.setText(input + "^2" + " = " + m);
			history.setText(history.getText() + result_text.getText() + "\n");
		}
		else if(Objects.equals(label,"sqr")) {
			String m;
			if(input.isEmpty()) m = "error";
			else m = String.valueOf(squart(input));
			result_text.setText("sqrt(" + input + ") = " + m);
			history.setText(history.getText() + result_text.getText() + "\n");
		}
		else if(Objects.equals(label,"abs")) {
			String m;
			if(input.isEmpty()) m = "error";
			else m = String.valueOf(abs(input));
			result_text.setText("abs(" + input + ") = " + m);
			history.setText(history.getText() + result_text.getText() + "\n");
		}
		else if(Objects.equals(label,"1/x")) {
			String m;
			if(input.isEmpty()) m = "error";
			else m = String.valueOf(daoshu(input));
			result_text.setText("1/" + input + " = " + m);
			history.setText(history.getText() + result_text.getText() + "\n");			
	    }
		else if(Objects.equals(label,"=")) {
			if(input.isEmpty()) return;
			String[] s = change(input);
			double result = result(s);
			result_text.setText(input + "=" + result);
	        history.setText(history.getText() + result_text.getText() + "\n");		
		}
		else {
			if(Objects.equals(label,"e")) 
				label = String.valueOf(2.718);
			else if(Objects.equals(label,"pi")) 
				label = String.valueOf(3.141);
			input = input + label;
			result_text.setText(input);
		}	
	}
	public String[] change(String str) {
		String s = "";
		Stack<String> optr = new Stack<String>();
		Stack<String> opnd = new Stack<String>();
        System.out.println("中缀：" + str);
		for(int i = 0; i < str.length(); i++) {
			if(str.charAt(i) >= '0' && str.charAt(i) <= '9') {
				s = "";
				for(; i < str.length() && str.charAt(i) >= '0' && str.charAt(i) <= '9'; i++)
					s += str.charAt(i);
				i--;
				opnd.push(s);
			}
			else if(str.charAt(i) == '(') {
				s = "";	s += str.charAt(i);
				optr.push(s);
			}
			else if(str.charAt(i) == ')') {
				while(optr.peek() != "(")
					opnd.push(optr.pop());
				optr.pop();
			}
			else if(str.charAt(i) == '+' || str.charAt(i) == '-' || str.charAt(i) == '*' || str.charAt(i) == '/') {
				if(optr.empty() || optr.peek() == "(") {
					s = "";	s += str.charAt(i);
					optr.push(s);
				}
				else {
                    boolean rule = ((optr.peek() == "+" || optr.peek() == "-" || optr.peek() == "*" || optr.peek() == "/" || optr.peek() == "%") && (str.charAt(i) == '+' || str.charAt(i) == '-')) 
                    		||((optr.peek() == "*" || optr.peek() == "/" || optr.peek() == "%") && (str.charAt(i) == '*' || str.charAt(i) == '/' || str.charAt(i) == '%'));
                    while(!optr.empty() && rule) 
                    	opnd.push(optr.pop());
                    s = "";	s += str.charAt(i);
					optr.push(s);
				}
			}
		}
		while(!optr.empty())
			opnd.push(optr.pop());
		String[] str_final = new String[opnd.size()];
		for(int i = opnd.size() - 1; i >= 0; i--)
		str_final[i] = opnd.pop();
        System.out.println("后缀：" + Arrays.toString(str_final.clone()));
		return str_final;
	}
	public double square(String t) { double temp = Double.parseDouble(t); return Math.pow(temp,2);}
	public double squart(String t) { double temp = Double.parseDouble(t); return Math.sqrt(temp);}
	public double abs(String t) { double temp = Double.parseDouble(t); return Math.abs(temp);}
	public double daoshu(String t) { double temp = Double.parseDouble(t);if(temp != 0) return 1/temp; else { System.out.println("wrong"); return 0;}}
	public double result(String[] str_final) {
		Stack<String> result = new Stack<>(); 顺序存储的栈，数据类型为字符串
        for(int i = 0; i < str_final.length; i++) {
            if(str_final[i].charAt(0) >= '0' && str_final[i].charAt(0) <= '9') 
                result.push(str_final[i]);
            else {   
                double x, y, n = 0;
                x = Double.parseDouble(result.pop());   
                y = Double.parseDouble(result.pop());
                switch (str_final[i]) {
                    case "*": n = y * x; break;
                    case "/":if (x == 0) return 000000; else n = y / x; break;
                    case "%":if (x == 0) return 000000; else n = y % x; break;
                    case "-": n = y - x; break;
                    case "+": n = y + x; break;
                }
                result.push(String.valueOf(n));  将运算结果重新入栈
            }
        }

        System.out.println("return:" + result.peek());
        return Double.parseDouble(result.peek());    返回最终结果
    }	
	public static void main(String args[]) {
		calculator c = new calculator();
	}
}


