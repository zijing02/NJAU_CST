package week16;

import java.io.Serializable;

public class Information implements Serializable {
    private String message;
    public Information(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}